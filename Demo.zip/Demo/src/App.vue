<template>
  <div id="app">
    <router-view />
  </div>
</template>
<script setup></script>
<style scoped lang="scss">
#app {
  height: 100%;
}
</style>
