<template>
  <div>123</div>
</template>
<script setup></script>
<style scoped lang="scss"></style>
